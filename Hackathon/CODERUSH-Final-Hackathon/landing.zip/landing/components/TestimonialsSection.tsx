import React from 'react';
import { Quote, Star, CheckCircle, Shield } from 'lucide-react';

export const TestimonialsSection: React.FC = () => {
  const testimonials = [
    {
      quote:
        'During mass-casualty expressway trauma cases, calling 6 different blood banks manually wasted 40 minutes of golden hour resuscitation. With PulseRelay, we had 4 units of O-negative locked from AIIMS and Safdarjung within 3.5 minutes.',
      author: 'Dr. Ananya Sen',
      initials: 'AS',
      role: 'Chief of Trauma & Acute Surgery',
      hospital: 'AIIMS Central Trauma Centre',
      metric: '3.5 min golden-hour lock',
      gradient: 'from-teal-600 to-emerald-700',
      badgeColor: 'text-emerald-700 bg-emerald-50 border-emerald-200/50',
    },
    {
      quote:
        'The atomic reservation mechanism is a game changer. We no longer worry about promising units to two different hospitals. Once an offer is accepted, the system handles the lock and notifies our cold-chain team automatically.',
      author: 'Dr. R. K. Bhatt',
      initials: 'RB',
      role: 'Director of Transfusion Medicine',
      hospital: 'Regional Blood Transfusion Centre',
      metric: 'Zero double-allocation errors',
      gradient: 'from-emerald-600 to-cyan-700',
      badgeColor: 'text-teal-700 bg-teal-50 border-teal-200/50',
    },
    {
      quote:
        'Clinical compliance and audit traceability are paramount in blood banking. Having cryptographic logs of who offered units, when they were reserved, and recipient verification gives our hospital complete governance confidence.',
      author: 'Dr. Neha Malhotra',
      initials: 'NM',
      role: 'Head of Quality & Compliance',
      hospital: 'Max Healthcare Institute',
      metric: '100% Audit Compliance',
      gradient: 'from-cyan-600 to-teal-800',
      badgeColor: 'text-cyan-700 bg-cyan-50 border-cyan-200/50',
    },
  ];

  return (
    <section className="py-24 relative overflow-hidden bg-gradient-to-b from-transparent via-[#e7f3f1]/50 to-transparent">
      {/* Decorative ambient spots */}
      <div className="absolute top-1/3 right-1/4 w-80 h-80 bg-teal-300/15 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-teal-50 border border-teal-200/60 text-[#0d9488] text-[11px] font-black uppercase tracking-wider mb-3 shadow-xs">
            <Shield className="w-3.5 h-3.5" />
            <span>Clinical Trust & Verification</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-900 tracking-tight">
            Trusted by Critical Care Leaders
          </h2>
          <p className="text-sm sm:text-base text-slate-600 mt-3 font-medium">
            Read how trauma surgeons, blood bank directors, and health authorities depend on PulseRelay.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map((t, idx) => (
            <div
              key={idx}
              className="group relative bg-white/75 hover:bg-white backdrop-blur-md rounded-3xl p-8 border border-teal-900/10 hover:border-teal-500/30 shadow-sm hover:shadow-xl hover:shadow-teal-950/5 hover:-translate-y-1.5 transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                {/* Metric pill & Stars */}
                <div className="flex items-center justify-between mb-5">
                  <div className="flex items-center space-x-1 text-amber-400">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                    ))}
                  </div>
                  <span className={`text-[10px] font-bold tracking-wide px-2.5 py-1 rounded-full border ${t.badgeColor}`}>
                    {t.metric}
                  </span>
                </div>

                <div className="relative mb-6">
                  <Quote className="w-8 h-8 text-teal-200/50 absolute -top-3 -left-2 -z-0 pointer-events-none" />
                  <p className="text-xs sm:text-sm text-slate-600 leading-relaxed font-normal italic relative z-10">
                    "{t.quote}"
                  </p>
                </div>
              </div>

              <div className="pt-5 border-t border-slate-100 flex items-center space-x-3.5">
                <div className="relative shrink-0">
                  <div
                    className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${t.gradient} text-white font-black text-sm tracking-wider flex items-center justify-center shadow-md shadow-teal-900/15 ring-2 ring-teal-500/30 group-hover:ring-teal-500 transition-all`}
                  >
                    {t.initials}
                  </div>
                  <div className="absolute -bottom-1 -right-1 bg-teal-600 text-white rounded-full p-0.5 shadow-sm ring-2 ring-white">
                    <CheckCircle className="w-3 h-3" />
                  </div>
                </div>
                <div>
                  <h4 className="text-xs sm:text-sm font-extrabold text-slate-900 group-hover:text-teal-900 transition-colors">
                    {t.author}
                  </h4>
                  <p className="text-[11px] text-teal-700 font-semibold">{t.role}</p>
                  <p className="text-[10px] text-slate-400 font-medium">{t.hospital}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
